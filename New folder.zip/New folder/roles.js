const roles = {
    admin: ['read' , 'write' , 'delete'],
    user: ['read'],
    guest:[]
};

module.exports = roles; 