const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    id : {
        type: Number,
        required: true 
    },
    productName : {
        type: String,
        required: true 
    },
    productPrice : {
        type: String,
        required: true 
    }
},
{
    timestamps: true
}
);

const Products = mongoose.model('Products' , productSchema);

module.exports = Products;