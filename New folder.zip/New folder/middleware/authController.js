const jwt = require("jsonwebtoken");
const roles = require("../roles");

const generateToken = (user) => {
  const token = jwt.sign(
    {
      id: user.id,
      role: user.role,
    },
    "",
    { expiresIn: "1h" }
  );
  return token;
};

module.exports = generateToken;
