const roles = require("../roles");

const checkRole = (role) => {
  return (req, res, next) => {
    const { userRole } = req.user.role;
    if (roles[userRole].include(role)) {
      next();
    } else {
      return res.status(403).json({
        message: "Unauthorised Access",
      });
    }
  };
};

module.exports = checkRole;
