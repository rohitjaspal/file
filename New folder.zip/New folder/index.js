require('dotenv').config()
const express = require('express');
const cors = require('cors');
const app = express();
const routes = require('./routes/routes');
const connection = require('./config/mongoose');

const port= process.env.PORT;
app.use(cors());

app.use(express.json());

app.use('/' , routes);

const start = async() => {
    try{
        await connection();
        app.listen(port , () => {
            console.log('connection established successfully' , port);
        })

    }catch(error){
            console.log(error)
    }
}

start();