require('dotenv').config();
const mongoose = require('mongoose');

const connection = async() => {
try{
     mongoose.connect(`${process.env.URI}` , {
                family: 4
    });
    
    
    // handling db connection
    console.log('database connected to mongodb ');
}catch(err){
    console.log(err.message);
}
    
}
module.exports = connection;

