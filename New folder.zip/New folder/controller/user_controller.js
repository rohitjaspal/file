const User = require('../models/User');
const bcrypt = require('bcryptjs');
const salt = 10;
const jwt = require('jsonwebtoken');

// registering the user

module.exports.createUser = async(req, res) => {
    try {
    const { firstname , lastname , email , password , cp , mobile , address } = req.body;
        console.log("data" , req.body);
        if(!firstname || !lastname || !email || !password || !cp || !mobile || !address) {
            return res.status(501).json({
                message: 'Fields cannot be empty. Please fill all the fields.'
            })
        }

        if(password !== cp){
            return res.status(401).json({
                message: 'both password and complete password must be matching'
            })
        }
        console.log("line no 24");
        let allUsers = await User.findOne({email:email});
        console.log("line no 26" , allUsers);
        if(!allUsers) {
            const hash = await bcrypt.hash(password , 14);
            const newUser = new User({
                firstname , lastname , password:hash , address , mobile , email
            }) 
            // bcrypt.hash(password , salt , async(err , hash) => {
            //     const newUser = await User.create({
            //         firstname , lastname , password:hash , address , mobile , email
            //     });
                console.log("newUser",newUser);
             await newUser.save();
                console.log("savedUser",newUser);
                if(!newUser){
                    return res.status(501).json({
                        message: 'Error in creating the User'
                    })
                }else{
                    return res.status(200).json({
                        message: 'User created Successfully',
                        data: savedUser
                    })
                }
            
        } else {
            return res.status(301).json({
                message: 'User already exists. Please Login to continue..'
            })
        }
    } catch(error){
        return res.status(501).json({
            message: 'Internal Server Error',
            error:error.message
        })
    }
}


// LOGIN

module.exports.createSession = async(req, res) => {
    try
    {
        const {email , password } = req.body;
        if(!email | !password){
            return res.status(501).json({
                message: 'Please Fill the email and password field.'
            })
        }
        let allUsers = await User.findOne({email: email});
        if(!allUsers){
            console.log('cannot find user.');
            return res.status(422).json({
                message: 'Unauthorized Access'
            })
        }else{
            let result = await bcrypt.compare(password , allUsers.password)
            if(result) {
                let token = jwt.sign(allUsers.toJSON() ,`${process.env.SECRET}`,{expiresIn: '10000000'});
                res.cookie('jwt' , token)
                return res.status(200).json({
                    message:'Login Successfully',
                    data: token
                })
            }else{
                return res.status(401).json({
                    message: 'Invalid email or password'
                })
            }
        } 
    }
    catch(error)
    {
        return res.status(501).json({
            message: 'Internal Server Error'
        })
    }
}


// delete a User from Database

module.exports.deleteUser = async(req, res) => {
    try
    {
        const { email } = req.body;
        if(!email){
            return res.status(501).json({
                message: 'Please Provide the email id'
            })
        }
        let allUsers = await User.findOne({email: email});

         if(!allUsers){
            console.log('cannot find user.' , allUsers);
            return res.status(422).json({
                message: 'Unauthorized Access'
            })    
         }else{
            await allUsers.deleteOne();
            return res.status(200).json({
                            message:'Email ID deleted Successfully'
                        })
         }
    }
    catch(error)
    {
        return res.status(501).json({
            message: 'Internal Server Error'
        })
    }
}

// Update the User Data in Database

module.exports.updateUser = async(req,res) => {
    console.log('testing' , req.body);
    try 
    {
        const { firstname , lastname , email , address , mobile , cp , password } = req.body;
            let allUsers = await User.findOne({email: email});
            console.log('allusers' , allUsers);
            if(!allUsers){
                return res.status(401).json({
                    message:'No User registered with this Email ID.'
                })
            }else{
                console.log('update query' , allUsers);
                const result = await allUsers.findOneAndUpdate(
                {...allUsers} ,
                {$set:{firstname : req.body.firstname , lastname: req.body.lastname}},
                {new: true}
            );
            console.log('update query' , result);
            return res.status(200).json({
                message:'Record Updated Successfully',
                data: result
            })
            }
    } catch (error) 
    {
        return res.status(501).json({
            message: 'something went wrong. data updation failed',
            error: error.message
        })
    }

}