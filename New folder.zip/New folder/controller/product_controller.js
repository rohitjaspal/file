const Product = require("../models/Product");

// Create a new product
module.exports.createNewProduct = async (req, res) => {
  try {
    const { id, productName, productPrice } = req.body;
    // Validation starts

    // Validation for Required Fields
    if (!id || !productName || !productPrice)
      return res
        .status(501)
        .json({ message: "Product Fields cannot be empty" });

    // Validation for wrong Input in the Fields
    if (typeof id !== 'number')
      return res
        .status(501)
        .json({ message: "Product id must be of number type only." });

    if (typeof productName !== 'string')
      return res
        .status(501)
        .json({ message: "Product name must be of string type only." });

    if (typeof productPrice !== 'number')
      return res
        .status(501)
        .json({ message: "Product price must be of number type only." });

    // Validation End

    // Registering New Product in database

    let pToBeCreated = await Product.findOne({ id: id });
    if (!pToBeCreated) {
      const newProduct = await Product.create({
        id,
        productName,
        productPrice,
      });

      const newSavedProduct = await newProduct.save();

      if (!newSavedProduct)
        return res
          .status(501)
          .json({ message: " Error in creating new product" });
      else {
        return res.status(200).json({
          message: "New Product created Successfully",
          data: newSavedProduct,
        });
      }
    } else {
      return res.status(301).json({
        message: "Product exists already..",
      });
    }
  } catch (error) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

//
