const jwt = require('jasonwebtoken');
require('dotenv')

export const token = (async (user) => {
    const {firstName , lastName , email , _id } = user;
    const payLoad = {
        firstName , lastName , email , _id 
    }  
    const token  = await jwt.sign(payLoad , process.env.SECRET , { expiresIn: "24H"});
    return token;
})