const express = require('express');
const router = express.Router();
const userController = require('../controller/user_controller.js');
const productController = require('../controller/product_controller.js');
const checkRole = require('./../middleware/roles.middleware.js');

router.post('/create-user' , userController.createUser);
router.post('/create-session' , userController.createSession);
router.post('/deleteUser' , checkRole , userController.deleteUser);
router.post('/create-product',  productController.createNewProduct);


module.exports = router;